/**
 * main.js - Script chính cho NhaUyenFlower Frontend
 *
 * Bao gồm các chức năng UI cơ bản như:
 * - Menu mobile
 * - Bật/tắt thanh tìm kiếm
 * - Xử lý nút tăng/giảm số lượng (cơ bản)
 * - Chuyển đổi ảnh thumbnail trong gallery chi tiết sản phẩm
 * - Chuyển đổi tab trong chi tiết sản phẩm
 * - Hiển thị/ẩn mô tả phương thức thanh toán
 */

// Đảm bảo script chỉ chạy sau khi toàn bộ DOM đã được tải
document.addEventListener('DOMContentLoaded', () => {
  console.log('NhaUyenFlower Frontend JS Initialized'); // Log để kiểm tra

  initMobileMenu();
  initSearchToggle();
  initQuantityButtons();
  initImageGallery();
  initTabs();
  initPaymentMethods();
  // Gọi các hàm khởi tạo khác ở đây (nếu có)
});

/**
 * Khởi tạo chức năng bật/tắt menu mobile
 */
function initMobileMenu() {
  const menuToggleButton = document.querySelector('.mobile-menu-toggle');
  const mainNavigation = document.querySelector('.main-navigation');

  // Kiểm tra xem các phần tử có tồn tại không
  if (menuToggleButton && mainNavigation) {
    menuToggleButton.addEventListener('click', () => {
      mainNavigation.classList.toggle('mobile-active'); // Thêm/xóa class để hiện/ẩn menu
      // Thay đổi icon nút bấm (tùy chọn)
      menuToggleButton.textContent = mainNavigation.classList.contains('mobile-active') ? '✕' : '☰';
      // Ngăn cuộn trang khi menu mở (tùy chọn)
      // document.body.style.overflow = mainNavigation.classList.contains('mobile-active') ? 'hidden' : '';
    });
  } else {
    // console.warn('Mobile menu elements not found.'); // Log cảnh báo nếu không tìm thấy
  }
}

/**
 * Khởi tạo chức năng bật/tắt thanh tìm kiếm
 */
function initSearchToggle() {
  const searchToggleButton = document.querySelector('.search-toggle');
  const searchBar = document.querySelector('.search-bar');

  if (searchToggleButton && searchBar) {
    searchToggleButton.addEventListener('click', (event) => {
      event.stopPropagation(); // Ngăn sự kiện click lan ra ngoài
      searchBar.classList.toggle('active');
      if (searchBar.classList.contains('active')) {
        // Tự động focus vào ô input khi mở thanh tìm kiếm
        const searchInput = searchBar.querySelector('input[type="search"]');
        if (searchInput) {
          searchInput.focus();
        }
      }
    });

    // (Tùy chọn) Đóng thanh tìm kiếm khi click ra ngoài
    document.addEventListener('click', (event) => {
      if (searchBar.classList.contains('active') && !searchBar.contains(event.target) && event.target !== searchToggleButton) {
        searchBar.classList.remove('active');
      }
    });

  } else {
    // console.warn('Search toggle elements not found.');
  }
}

/**
 * Khởi tạo chức năng cho các nút tăng/giảm số lượng
 * Lưu ý: Phần này chỉ cập nhật ô input, chưa xử lý logic giỏ hàng/tổng tiền.
 */
function initQuantityButtons() {
  const quantityContainers = document.querySelectorAll('.quantity-selector');

  quantityContainers.forEach(container => {
    const minusButton = container.querySelector('.quantity-btn.minus');
    const plusButton = container.querySelector('.quantity-btn.plus');
    const quantityInput = container.querySelector('.quantity-input');

    if (minusButton && plusButton && quantityInput) {
      minusButton.addEventListener('click', () => {
        let currentValue = parseInt(quantityInput.value, 10);
        if (currentValue > 1) { // Đảm bảo số lượng không nhỏ hơn 1
          quantityInput.value = currentValue - 1;
          // Trigger sự kiện 'change' để các script khác (nếu có) có thể lắng nghe
          quantityInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });

      plusButton.addEventListener('click', () => {
        let currentValue = parseInt(quantityInput.value, 10);
        // Có thể thêm giới hạn số lượng tối đa nếu cần (vd: quantityInput.max)
        quantityInput.value = currentValue + 1;
        // Trigger sự kiện 'change'
        quantityInput.dispatchEvent(new Event('change', { bubbles: true }));
      });

      // Ngăn nhập số âm hoặc số 0 trực tiếp (tùy chọn)
      quantityInput.addEventListener('change', () => {
        let currentValue = parseInt(quantityInput.value, 10);
        if (isNaN(currentValue) || currentValue < 1) {
          quantityInput.value = 1;
        }
         // Trigger sự kiện 'change' lần nữa sau khi đã sửa giá trị
         quantityInput.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
  });
}

/**
 * Khởi tạo chức năng chuyển đổi ảnh trong gallery chi tiết sản phẩm
 */
function initImageGallery() {
  const mainImage = document.getElementById('main-product-image');
  const thumbnails = document.querySelectorAll('.thumbnail-images .thumbnail');

  // Chỉ chạy nếu có đủ các phần tử cần thiết (tránh lỗi ở các trang khác)
  if (mainImage && thumbnails.length > 0) {
    thumbnails.forEach(thumb => {
      thumb.addEventListener('click', () => {
        // Lấy đường dẫn ảnh lớn từ thuộc tính data-image
        const newImageSrc = thumb.dataset.image;
        if (newImageSrc) {
          mainImage.src = newImageSrc;
          mainImage.alt = thumb.alt; // Cập nhật alt text

          // Bỏ class 'active' khỏi tất cả thumbnail
          thumbnails.forEach(t => t.classList.remove('active'));
          // Thêm class 'active' cho thumbnail vừa được click
          thumb.classList.add('active');
        }
      });

      // (Tùy chọn) Xử lý nhấn Enter trên thumbnail (Accessibility)
      thumb.addEventListener('keydown', (event) => {
          if (event.key === 'Enter') {
              thumb.click(); // Giả lập hành động click
          }
      });
    });
  }
}

/**
 * Khởi tạo chức năng chuyển đổi tab (ví dụ: trong trang chi tiết sản phẩm)
 */
function initTabs() {
  const tabLinks = document.querySelectorAll('.tabs-nav .tab-link');
  const tabPanes = document.querySelectorAll('.tabs-content .tab-pane');

  // Chỉ chạy nếu có tab
  if (tabLinks.length > 0 && tabPanes.length > 0) {
    tabLinks.forEach(link => {
      link.addEventListener('click', (event) => {
        event.preventDefault(); // Ngăn hành vi mặc định của thẻ a

        const targetTabId = link.dataset.tab; // Lấy ID của tab cần hiển thị từ data-tab

        // Bỏ class 'active' khỏi tất cả các link và pane
        tabLinks.forEach(l => l.classList.remove('active'));
        tabPanes.forEach(p => p.classList.remove('active'));

        // Thêm class 'active' cho link được click và pane tương ứng
        link.classList.add('active');
        const targetPane = document.getElementById(targetTabId);
        if (targetPane) {
          targetPane.classList.add('active');
        } else {
          console.error(`Tab pane with id "${targetTabId}" not found.`);
        }
      });
    });
  }
}

/**
 * Khởi tạo chức năng hiển thị/ẩn mô tả phương thức thanh toán
 */
function initPaymentMethods() {
    const paymentMethodRadios = document.querySelectorAll('input[name="payment_method"]');
    const paymentDescriptions = document.querySelectorAll('.payment-methods .payment-description');

    // Chỉ chạy nếu có các yếu tố cần thiết
    if (paymentMethodRadios.length > 0 && paymentDescriptions.length > 0) {
        const toggleDescription = () => {
            let selectedMethod = '';
            // Tìm radio đang được chọn
            paymentMethodRadios.forEach(radio => {
                if (radio.checked) {
                    selectedMethod = radio.value;
                }
            });

            // Ẩn tất cả mô tả
            paymentDescriptions.forEach(desc => {
                desc.style.display = 'none';
            });

            // Hiển thị mô tả tương ứng với phương thức được chọn
            const activeDescription = document.querySelector(`.payment-description[data-method="${selectedMethod}"]`);
            if (activeDescription) {
                activeDescription.style.display = 'block';
            }
        };

        // Lắng nghe sự kiện thay đổi trên các radio button
        paymentMethodRadios.forEach(radio => {
            radio.addEventListener('change', toggleDescription);
        });

        // Gọi lần đầu để hiển thị mô tả cho phương thức được chọn mặc định
        toggleDescription();
    }
}


// ========================================================================
// Các hàm tiện ích khác có thể thêm vào đây (ví dụ: debounce, throttle,...)
// ========================================================================
