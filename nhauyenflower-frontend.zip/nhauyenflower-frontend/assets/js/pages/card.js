/**
 * card.js - Script xử lý tương tác cho thành phần Card chung
 *
 * Chức năng chính:
 * - Làm cho toàn bộ thẻ (.card) có thể nhấp được nếu nó chứa một liên kết chính (.card-main-link).
 */

document.addEventListener('DOMContentLoaded', () => {
  console.log('Card JS Initialized'); // Log để kiểm tra

  initClickableCards();

});

/**
 * Khởi tạo chức năng nhấp cho các thẻ (.card)
 * Tìm thẻ 'a' có class 'card-main-link' bên trong thẻ và làm cho cả thẻ điều hướng đến link đó.
 */
function initClickableCards() {
  const cards = document.querySelectorAll('.card');

  cards.forEach(card => {
    // Tìm liên kết chính đầu tiên bên trong thẻ
    const mainLink = card.querySelector('a.card-main-link');

    if (mainLink) {
      // Thêm class để thay đổi con trỏ chuột (cần CSS tương ứng)
      card.classList.add('card-clickable');

      card.addEventListener('click', (event) => {
        // Kiểm tra xem phần tử được nhấp có phải là một phần tử tương tác khác không
        // (ví dụ: một link khác, nút bấm, input bên trong thẻ)
        const isInteractiveElement = event.target.closest('a, button, input, select, textarea');

        // Chỉ điều hướng nếu nhấp vào phần không tương tác của thẻ
        // và phần tử được nhấp không phải chính là link chính (để tránh xử lý lặp)
        if (!isInteractiveElement || event.target === card) {

          // Kiểm tra xem link có mở tab mới không
          if (mainLink.target === '_blank') {
            window.open(mainLink.href, '_blank', 'noopener noreferrer');
          } else {
            // Điều hướng cửa sổ hiện tại
            window.location.href = mainLink.href;
          }
        }
        // Nếu nhấp vào một phần tử tương tác khác (isInteractiveElement = true),
        // trình duyệt sẽ tự xử lý hành động mặc định của phần tử đó (ví dụ: mở link khác, bấm nút).
      });
    }
  });
}
