/**
 * checkout-validation.js - Script xử lý validation cho form Thanh toán
 *
 * Thực hiện kiểm tra dữ liệu phía client trước khi gửi form.
 */

document.addEventListener('DOMContentLoaded', () => {
  console.log('Checkout Validation JS Initialized'); // Log để kiểm tra

  const checkoutForm = document.getElementById('checkout-form');

  if (checkoutForm) {
    checkoutForm.addEventListener('submit', (event) => {
      // Ngăn chặn hành vi gửi form mặc định
      event.preventDefault();
      console.log('Form submission intercepted for validation.');

      // Thực hiện validation
      const isFormValid = validateCheckoutForm(checkoutForm);

      if (isFormValid) {
        console.log('Form is valid. Submitting...');
        // Nếu form hợp lệ, cho phép gửi đi (hoặc xử lý bằng AJAX)
        // checkoutForm.submit(); // Bỏ comment dòng này để gửi form theo cách truyền thống
        alert('DEBUG: Form hợp lệ! (Trong thực tế sẽ gửi form đi)'); // Thông báo tạm thời
      } else {
        console.log('Form is invalid. Please check errors.');
        // (Tùy chọn) Cuộn đến trường lỗi đầu tiên
        const firstError = checkoutForm.querySelector('.form-group .invalid');
        if (firstError) {
          firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
          firstError.focus(); // Focus vào trường lỗi đầu tiên
        }
      }
    });
  } else {
    console.warn('Checkout form (#checkout-form) not found.');
  }
});

/**
 * Hàm thực hiện kiểm tra toàn bộ form thanh toán
 * @param {HTMLFormElement} form - Phần tử form cần kiểm tra
 * @returns {boolean} - True nếu form hợp lệ, False nếu có lỗi
 */
function validateCheckoutForm(form) {
  let isFormValid = true; // Giả định form hợp lệ ban đầu

  // Xóa tất cả các thông báo lỗi và class 'invalid' cũ
  clearAllErrors(form);

  // Lấy tất cả các trường bắt buộc (có thuộc tính required)
  const requiredFields = form.querySelectorAll('[required]');

  requiredFields.forEach(field => {
    const fieldGroup = field.closest('.form-group'); // Tìm .form-group cha
    if (!fieldGroup) return; // Bỏ qua nếu không tìm thấy group

    let isValid = true;
    let errorMessage = '';

    // 1. Kiểm tra trường rỗng (áp dụng cho hầu hết các loại)
    if (field.type === 'checkbox') {
      if (!field.checked) {
        isValid = false;
        errorMessage = 'Bạn cần đồng ý với điều khoản này.';
      }
    } else if (field.value.trim() === '') {
      isValid = false;
      // Lấy tên trường từ label hoặc placeholder để tạo thông báo lỗi chung
      const label = fieldGroup.querySelector('label');
      const fieldName = label ? label.textContent.replace('*', '').trim() : 'Trường này';
      errorMessage = `${fieldName} là bắt buộc.`;
      // Thông báo lỗi cụ thể hơn cho select
      if (field.tagName === 'SELECT') {
          errorMessage = `Vui lòng chọn ${fieldName.toLowerCase()}.`;
      }
    }

    // 2. Kiểm tra định dạng Email (nếu là trường email và không rỗng)
    if (isValid && field.type === 'email') {
      if (!isValidEmail(field.value.trim())) {
        isValid = false;
        errorMessage = 'Vui lòng nhập địa chỉ email hợp lệ.';
      }
    }

    // 3. Kiểm tra định dạng Số điện thoại (nếu là trường tel và không rỗng - kiểm tra cơ bản)
    if (isValid && field.type === 'tel') {
      if (!isValidPhone(field.value.trim())) {
        isValid = false;
        errorMessage = 'Vui lòng nhập số điện thoại hợp lệ.';
      }
    }

    // Hiển thị hoặc xóa lỗi cho trường hiện tại
    if (!isValid) {
      showError(field, errorMessage);
      isFormValid = false; // Đánh dấu form không hợp lệ nếu có bất kỳ lỗi nào
    } else {
      clearError(field);
    }
  });

  return isFormValid;
}

/**
 * Hiển thị thông báo lỗi cho một trường input/select/textarea
 * @param {HTMLElement} field - Phần tử input/select/textarea bị lỗi
 * @param {string} message - Thông báo lỗi cần hiển thị
 */
function showError(field, message) {
  field.classList.add('invalid'); // Thêm class để đổi style (vd: viền đỏ)
  const fieldGroup = field.closest('.form-group');
  if (fieldGroup) {
    const errorElement = fieldGroup.querySelector('.error-message');
    if (errorElement) {
      errorElement.textContent = message;
      errorElement.style.display = 'block'; // Hiển thị thông báo lỗi
    }
  }
}

/**
 * Xóa thông báo lỗi và trạng thái lỗi của một trường
 * @param {HTMLElement} field - Phần tử input/select/textarea
 */
function clearError(field) {
  field.classList.remove('invalid'); // Xóa class lỗi
  const fieldGroup = field.closest('.form-group');
  if (fieldGroup) {
    const errorElement = fieldGroup.querySelector('.error-message');
    if (errorElement) {
      errorElement.textContent = ''; // Xóa nội dung lỗi
      errorElement.style.display = 'none'; // Ẩn thông báo lỗi
    }
  }
}

/**
 * Xóa tất cả các thông báo lỗi và trạng thái lỗi trên form
 * @param {HTMLFormElement} form - Phần tử form
 */
function clearAllErrors(form) {
  const invalidFields = form.querySelectorAll('.invalid');
  invalidFields.forEach(field => {
    clearError(field);
  });
  // Cũng có thể ẩn thông báo lỗi chung của form nếu có
  // const formError = form.querySelector('.form-message.error');
  // if (formError) formError.style.display = 'none';
}

/**
 * Kiểm tra định dạng email cơ bản
 * @param {string} email - Chuỗi email cần kiểm tra
 * @returns {boolean} - True nếu hợp lệ, False nếu không
 */
function isValidEmail(email) {
  // Regex đơn giản để kiểm tra email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Kiểm tra định dạng số điện thoại cơ bản (ví dụ: chỉ chứa số, độ dài nhất định)
 * @param {string} phone - Chuỗi số điện thoại cần kiểm tra
 * @returns {boolean} - True nếu hợp lệ, False nếu không
 */
function isValidPhone(phone) {
  // Regex đơn giản: chỉ chứa số, khoảng trắng, dấu -, dấu +, và có ít nhất 9 chữ số
  const phoneRegex = /^(?=.*\d)[\d\s()+-]{9,}$/;
  // Hoặc regex chặt hơn cho SĐT Việt Nam (ví dụ: 10 số, bắt đầu bằng 0)
  // const vietnamPhoneRegex = /^0\d{9}$/;
  // return vietnamPhoneRegex.test(phone);
  return phoneRegex.test(phone);
}
