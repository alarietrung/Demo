/**
 * slider.js - Khởi tạo và cấu hình các slider sử dụng thư viện SwiperJS
 */

document.addEventListener('DOMContentLoaded', () => {
  console.log('Slider JS Initialized'); // Log để kiểm tra

  initTestimonialSlider();
  initRelatedProductsStore();
  // Gọi các hàm khởi tạo slider khác ở đây (nếu có)

});

/**
 * Khởi tạo slider cho khu vực Testimonials (Đánh giá khách hàng)
 */
function initTestimonialSlider() {
  // Kiểm tra xem phần tử slider có tồn tại trên trang không
  const testimonialSliderEl = document.querySelector('.testimonial-slider');

  if (testimonialSliderEl) {
    const testimonialSwiper = new Swiper(testimonialSliderEl, {
      // Các tùy chọn cấu hình SwiperJS
      // Xem tài liệu SwiperJS để biết đầy đủ các tùy chọn: https://swiperjs.com/swiper-api

      slidesPerView: 1, // Hiển thị 1 slide mỗi lần xem trên màn hình nhỏ
      spaceBetween: 30, // Khoảng cách giữa các slide (nếu slidesPerView > 1)
      loop: true, // Lặp lại vô hạn
      grabCursor: true, // Hiển thị con trỏ tay khi di chuột

      // Tự động chạy (Autoplay)
      autoplay: {
        delay: 5000, // Thời gian dừng giữa các slide (5 giây)
        disableOnInteraction: false, // Không dừng autoplay khi người dùng tương tác
        pauseOnMouseEnter: true, // Dừng khi di chuột vào slider
      },

      // Phân trang (Dots)
      pagination: {
        el: '.swiper-pagination', // Selector của container chứa dots
        clickable: true, // Cho phép click vào dot để chuyển slide
      },

      // Nút điều hướng (Prev/Next)
      navigation: {
        nextEl: '.swiper-button-next', // Selector của nút next
        prevEl: '.swiper-button-prev', // Selector của nút prev
      },

      // Cấu hình responsive (điều chỉnh tùy chọn cho các kích thước màn hình khác nhau)
      // breakpoints: {
      //   // Ví dụ: khi màn hình >= 768px
      //   768: {
      //     slidesPerView: 2,
      //     spaceBetween: 20
      //   },
      //   // Ví dụ: khi màn hình >= 992px
      //   992: {
      //     slidesPerView: 3,
      //     spaceBetween: 30
      //   }
      // }
    });
    console.log('Testimonial Swiper initialized');
  } else {
    // console.log('Testimonial slider element not found on this page.');
  }
}


/**
 * Khởi tạo slider cho khu vực Sản phẩm liên quan
 */
function initRelatedProductsStore() {
  const relatedSliderEl = document.querySelector('.related-products-slider');

  if (relatedSliderEl) {
    const relatedSwiper = new Swiper(relatedSliderEl, {
      // Cấu hình cho slider sản phẩm liên quan
      slidesPerView: 2, // Hiển thị 2 slide trên mobile
      spaceBetween: 15, // Khoảng cách nhỏ hơn
      loop: false, // Thường không cần lặp cho sản phẩm liên quan
      grabCursor: true,

      // Phân trang
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },

      // Nút điều hướng
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },

      // Responsive breakpoints
      breakpoints: {
        // Khi màn hình >= 576px
        576: {
          slidesPerView: 3,
          spaceBetween: 20
        },
        // Khi màn hình >= 992px
        992: {
          slidesPerView: 4, // Hiển thị 4 sản phẩm
          spaceBetween: 30
        }
      }
    });
     console.log('Related Products Swiper initialized');
  } else {
    // console.log('Related products slider element not found on this page.');
  }
}
