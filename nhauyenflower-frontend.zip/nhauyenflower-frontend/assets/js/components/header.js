/**
 * header.js - Script xử lý các tương tác cho Header của NhaUyenFlower
 *
 * Bao gồm:
 * - Menu mobile toggle
 * - Search bar toggle
 */

document.addEventListener('DOMContentLoaded', () => {
  console.log('Header JS Initialized'); // Log để kiểm tra

  initMobileMenu();
  initSearchToggle();
});

/**
 * Khởi tạo chức năng bật/tắt menu mobile
 */
function initMobileMenu() {
  const menuToggleButton = document.querySelector('.mobile-menu-toggle');
  const mainNavigation = document.querySelector('.main-navigation');

  // Kiểm tra xem các phần tử có tồn tại không
  if (menuToggleButton && mainNavigation) {
    menuToggleButton.addEventListener('click', () => {
      mainNavigation.classList.toggle('mobile-active'); // Thêm/xóa class để hiện/ẩn menu
      // Thay đổi icon nút bấm (tùy chọn)
      menuToggleButton.textContent = mainNavigation.classList.contains('mobile-active') ? '✕' : '☰';
      // Ngăn cuộn trang khi menu mở (tùy chọn)
      // document.body.style.overflow = mainNavigation.classList.contains('mobile-active') ? 'hidden' : '';
    });

    // (Tùy chọn) Đóng menu khi click vào một link trong menu mobile
    mainNavigation.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            if (mainNavigation.classList.contains('mobile-active')) {
                mainNavigation.classList.remove('mobile-active');
                menuToggleButton.textContent = '☰';
                // document.body.style.overflow = ''; // Bỏ khóa cuộn
            }
        });
    });

  } else {
    // console.warn('Mobile menu elements not found.'); // Log cảnh báo nếu không tìm thấy
  }
}

/**
 * Khởi tạo chức năng bật/tắt thanh tìm kiếm
 */
function initSearchToggle() {
  const searchToggleButton = document.querySelector('.search-toggle');
  const searchBar = document.querySelector('.search-bar');

  if (searchToggleButton && searchBar) {
    searchToggleButton.addEventListener('click', (event) => {
      event.stopPropagation(); // Ngăn sự kiện click lan ra ngoài
      searchBar.classList.toggle('active');
      if (searchBar.classList.contains('active')) {
        // Tự động focus vào ô input khi mở thanh tìm kiếm
        const searchInput = searchBar.querySelector('input[type="search"]');
        if (searchInput) {
          searchInput.focus();
        }
      }
    });

    // (Tùy chọn) Đóng thanh tìm kiếm khi click ra ngoài
    document.addEventListener('click', (event) => {
      // Kiểm tra xem click có nằm ngoài searchBar và nút toggle không
      if (searchBar.classList.contains('active') && !searchBar.contains(event.target) && !searchToggleButton.contains(event.target)) {
        searchBar.classList.remove('active');
      }
    });

    // (Tùy chọn) Đóng thanh tìm kiếm khi nhấn phím Escape
     searchBar.addEventListener('keydown', (event) => {
         if (event.key === 'Escape' && searchBar.classList.contains('active')) {
             searchBar.classList.remove('active');
         }
     });

  } else {
    // console.warn('Search toggle elements not found.');
  }
}
